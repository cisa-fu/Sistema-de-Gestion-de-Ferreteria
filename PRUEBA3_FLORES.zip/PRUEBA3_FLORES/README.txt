# PRUEBA3_FLORES - Sistema de Ferreteria (Django)

## Credenciales de acceso

| Usuario | Contrasena | Rol |
|---|---|---|
| administrador | 123456789_a | Administrador (acceso total) |
| general | 123453456789_a | General (solo listar y buscar) |

## Funcionalidades por rol

**Administrador**: listar productos, buscar producto por nombre, agregar producto, modificar producto, eliminar producto.

**General**: listar productos, buscar producto por nombre.

## Estructura de paginas
- `/` : Panel principal, con accesos segun el rol del usuario conectado
- `/productos/` : Listado de todos los productos
- `/productos/buscar/` : Busqueda de un producto especifico por nombre
- `/productos/crear/` : Agregar un nuevo producto (solo administrador)
- `/productos/<id>/editar/` : Modificar un producto existente (solo administrador)
- `/productos/<id>/eliminar/` : Eliminar un producto, con pantalla de confirmacion (solo administrador)
- `/accounts/login/` : Inicio de sesion
- `/accounts/logout/` : Cierre de sesion

## Respaldo de la base de datos
El archivo `BD_ferreteria.sql` adjunto junto a este README contiene la estructura y los datos de la base de datos al momento de la entrega (exportado desde phpMyAdmin).