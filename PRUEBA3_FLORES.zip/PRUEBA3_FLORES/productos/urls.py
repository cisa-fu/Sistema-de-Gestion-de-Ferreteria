from django.urls import path

from . import views
from .views import (
    ProductoCreateView,
    ProductoDeleteView,
    ProductoListView,
    ProductoUpdateView,
)

urlpatterns = [
    path('', views.principal, name='principal'),
    path('productos/', ProductoListView.as_view(), name='producto_lista'),
    path('productos/buscar/', views.producto_buscar, name='producto_buscar'),
    path('productos/crear/', ProductoCreateView.as_view(), name='producto_crear'),
    path('productos/<int:pk>/editar/', ProductoUpdateView.as_view(), name='producto_editar'),
    path('productos/<int:pk>/eliminar/', ProductoDeleteView.as_view(), name='producto_eliminar'),
]
