from django.db import models

CATEGORIA_CHOICES = [
    ('herramientas_manuales', 'Herramientas Manuales'),
    ('electricidad', 'Electricidad'),
    ('plomeria', 'Plomeria'),
    ('pinturas', 'Pinturas'),
    ('ferreteria_general', 'Ferreteria General'),
]


class Producto(models.Model):
    nombre = models.CharField(max_length=150)
    descripcion = models.TextField()
    stock = models.PositiveIntegerField(default=0)
    precio_unitario = models.DecimalField(max_digits=10, decimal_places=2)
    fecha_ingreso = models.DateField()
    categoria = models.CharField(max_length=50, choices=CATEGORIA_CHOICES)

    class Meta:
        verbose_name = 'Producto'
        verbose_name_plural = 'Productos'
        ordering = ['-id']

    def __str__(self):
        return self.nombre
