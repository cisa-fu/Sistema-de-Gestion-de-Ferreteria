from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, ListView, UpdateView

from .forms import ProductoForm
from .models import Producto


@login_required
def principal(request):
    return render(request, 'productos/principal.html')


class ProductoListView(LoginRequiredMixin, ListView):
    model = Producto
    template_name = 'productos/producto_list.html'
    context_object_name = 'productos'


@login_required
def producto_buscar(request):
    termino = request.GET.get('nombre', '').strip()
    productos = None
    if termino:
        productos = Producto.objects.filter(nombre__icontains=termino)
    contexto = {'productos': productos, 'termino': termino}
    return render(request, 'productos/producto_buscar.html', contexto)


class ProductoCreateView(LoginRequiredMixin, PermissionRequiredMixin, CreateView):
    model = Producto
    form_class = ProductoForm
    template_name = 'productos/producto_form.html'
    success_url = reverse_lazy('producto_lista')
    permission_required = 'productos.add_producto'

    def form_valid(self, form):
        respuesta = super().form_valid(form)
        messages.success(self.request, 'Producto agregado correctamente')
        return respuesta


class ProductoUpdateView(LoginRequiredMixin, PermissionRequiredMixin, UpdateView):
    model = Producto
    form_class = ProductoForm
    template_name = 'productos/producto_form.html'
    success_url = reverse_lazy('producto_lista')
    permission_required = 'productos.change_producto'

    def form_valid(self, form):
        respuesta = super().form_valid(form)
        messages.success(self.request, 'Producto modificado correctamente')
        return respuesta


class ProductoDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    model = Producto
    template_name = 'productos/producto_confirm_delete.html'
    success_url = reverse_lazy('producto_lista')
    permission_required = 'productos.delete_producto'

    def form_valid(self, form):
        respuesta = super().form_valid(form)
        messages.success(self.request, 'Producto eliminado correctamente')
        return respuesta
