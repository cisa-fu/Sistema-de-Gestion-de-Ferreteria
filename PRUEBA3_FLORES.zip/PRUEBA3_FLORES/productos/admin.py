from django.contrib import admin

from .models import Producto


@admin.register(Producto)
class ProductoAdmin(admin.ModelAdmin):
    list_display = ('id', 'nombre', 'categoria', 'stock', 'precio_unitario', 'fecha_ingreso')
    search_fields = ('nombre', 'descripcion')
    list_filter = ('categoria',)
