from datetime import date

import django.apps
from django.contrib.auth.hashers import make_password
from django.contrib.auth.management import create_permissions
from django.db import migrations


def crear_permisos_pendientes():
    for configuracion in django.apps.apps.get_app_configs():
        configuracion.models_module = True
        create_permissions(configuracion, verbosity=0)
        configuracion.models_module = None


def crear_datos_iniciales(apps, schema_editor):
    crear_permisos_pendientes()

    Group = apps.get_model('auth', 'Group')
    Permission = apps.get_model('auth', 'Permission')
    User = apps.get_model('auth', 'User')
    ContentType = apps.get_model('contenttypes', 'ContentType')
    Producto = apps.get_model('productos', 'Producto')

    tipo_contenido = ContentType.objects.get(app_label='productos', model='producto')

    permisos_administrador = Permission.objects.filter(
        content_type=tipo_contenido,
        codename__in=['add_producto', 'change_producto', 'delete_producto', 'view_producto']
    )
    permisos_general = Permission.objects.filter(
        content_type=tipo_contenido,
        codename='view_producto'
    )

    grupo_administrador, _ = Group.objects.get_or_create(name='Administrador')
    grupo_administrador.permissions.set(permisos_administrador)

    grupo_general, _ = Group.objects.get_or_create(name='General')
    grupo_general.permissions.set(permisos_general)

    usuario_administrador, _ = User.objects.get_or_create(
        username='administrador',
        defaults={'is_staff': True, 'is_superuser': True}
    )
    usuario_administrador.password = make_password('123456789_a')
    usuario_administrador.is_staff = True
    usuario_administrador.is_superuser = True
    usuario_administrador.save()
    usuario_administrador.groups.add(grupo_administrador)

    usuario_general, _ = User.objects.get_or_create(
        username='general',
        defaults={'is_staff': False, 'is_superuser': False}
    )
    usuario_general.password = make_password('123453456789_a')
    usuario_general.save()
    usuario_general.groups.add(grupo_general)

    productos_iniciales = [
        {
            'nombre': 'Martillo de Carpintero',
            'descripcion': 'Martillo con mango de fibra de vidrio, cabeza de acero forjado',
            'stock': 25,
            'precio_unitario': 8990.00,
            'fecha_ingreso': date(2026, 6, 15),
            'categoria': 'herramientas_manuales',
        },
        {
            'nombre': 'Taladro Percutor 1/2 pulgada',
            'descripcion': 'Taladro electrico de 750W con maletin y accesorios',
            'stock': 10,
            'precio_unitario': 45990.00,
            'fecha_ingreso': date(2026, 7, 2),
            'categoria': 'herramientas_manuales',
        },
        {
            'nombre': 'Cable Electrico 2.5mm',
            'descripcion': 'Rollo de 100 metros, cable THHN para instalaciones domiciliarias',
            'stock': 40,
            'precio_unitario': 32990.00,
            'fecha_ingreso': date(2026, 5, 20),
            'categoria': 'electricidad',
        },
        {
            'nombre': 'Llave de Paso 1/2 pulgada',
            'descripcion': 'Llave de paso de bronce para agua potable',
            'stock': 30,
            'precio_unitario': 4990.00,
            'fecha_ingreso': date(2026, 8, 10),
            'categoria': 'plomeria',
        },
        {
            'nombre': 'Pintura Latex Blanco 1 galon',
            'descripcion': 'Pintura latex lavable para interiores, color blanco nieve',
            'stock': 18,
            'precio_unitario': 15990.00,
            'fecha_ingreso': date(2026, 4, 30),
            'categoria': 'pinturas',
        },
    ]

    for datos in productos_iniciales:
        Producto.objects.get_or_create(nombre=datos['nombre'], defaults=datos)


def eliminar_datos_iniciales(apps, schema_editor):
    Group = apps.get_model('auth', 'Group')
    User = apps.get_model('auth', 'User')
    Producto = apps.get_model('productos', 'Producto')

    User.objects.filter(username__in=['administrador', 'general']).delete()
    Group.objects.filter(name__in=['Administrador', 'General']).delete()
    Producto.objects.all().delete()


class Migration(migrations.Migration):

    dependencies = [
        ('productos', '0001_initial'),
        ('auth', '0001_initial'),
        ('contenttypes', '0001_initial'),
    ]

    operations = [
        migrations.RunPython(crear_datos_iniciales, eliminar_datos_iniciales),
    ]
