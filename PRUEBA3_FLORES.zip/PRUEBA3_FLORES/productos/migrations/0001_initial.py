from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name='Producto',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('nombre', models.CharField(max_length=150)),
                ('descripcion', models.TextField()),
                ('stock', models.PositiveIntegerField(default=0)),
                ('precio_unitario', models.DecimalField(decimal_places=2, max_digits=10)),
                ('fecha_ingreso', models.DateField()),
                ('categoria', models.CharField(choices=[
                    ('herramientas_manuales', 'Herramientas Manuales'),
                    ('electricidad', 'Electricidad'),
                    ('plomeria', 'Plomeria'),
                    ('pinturas', 'Pinturas'),
                    ('ferreteria_general', 'Ferreteria General'),
                ], max_length=50)),
            ],
            options={
                'verbose_name': 'Producto',
                'verbose_name_plural': 'Productos',
                'ordering': ['-id'],
            },
        ),
    ]
